git submodule update --init
npm start
